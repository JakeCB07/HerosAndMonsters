
public class HeroFactory
{

  
   public static Sorceress createSorceress()
    {
	return new Sorceress();
    }

    public static Thief createThief()
    {
	return new Thief();
    }

   public static Hero createWarrior()
   {
       return new Warrior();
   }






   

}
