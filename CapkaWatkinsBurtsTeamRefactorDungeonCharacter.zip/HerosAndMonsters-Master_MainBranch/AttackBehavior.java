
public interface AttackBehavior
{
    public void attack(DungeonCharacter attacker, DungeonCharacter oppenent);
}
